// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.layout');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('simplefrontend.reagent_wrapper');
/**
 * Provides main layout for the SPA.
 */
simplefrontend.layout.main_layout = (function simplefrontend$layout$main_layout(view){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.grid,view], null);
});

// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.products');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('reagent.core');
goog.require('ajax.core');
goog.require('simplefrontend.reagent_wrapper');
goog.require('simplefrontend.config');
simplefrontend.products.my_error_msg_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.products.my_success_msg_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.products.my_response_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.products.my_products_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.products.my_dev_products_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, ["1","2","Citizen Kane","12.32"], null),new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, ["2","2","Vertigo","31.98"], null)], null));
/**
 * Reset page atoms when coming here from home page.
 */
simplefrontend.products.reset_page = (function simplefrontend$products$reset_page(){
cljs.core.reset_BANG_(simplefrontend.products.my_response_atom,null);

cljs.core.reset_BANG_(simplefrontend.products.my_error_msg_atom,null);

return cljs.core.reset_BANG_(simplefrontend.products.my_success_msg_atom,null);
});
/**
 * The success (http status 200) handler.
 */
simplefrontend.products._handler = (function simplefrontend$products$_handler(response){
console.log(["ENTER -handler"].join(''));

cljs.core.reset_BANG_(simplefrontend.products.my_response_atom,response);

cljs.core.reset_BANG_(simplefrontend.products.my_products_atom,(function (){var fexpr__7590 = cljs.core.deref(simplefrontend.products.my_response_atom);
return (fexpr__7590.cljs$core$IFn$_invoke$arity$1 ? fexpr__7590.cljs$core$IFn$_invoke$arity$1("products") : fexpr__7590.call(null,"products"));
})());

cljs.core.reset_BANG_(simplefrontend.products.my_success_msg_atom,"TODO");

return cljs.core.reset_BANG_(simplefrontend.products.my_error_msg_atom,null);
});
/**
 * The error (http status not 200) handler.
 */
simplefrontend.products._error_handler = (function simplefrontend$products$_error_handler(response){
console.log(["ENTER -error-handler, response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

var error_msg = (function (){var fexpr__7591 = cljs.core.cst$kw$response.cljs$core$IFn$_invoke$arity$1(response);
return (fexpr__7591.cljs$core$IFn$_invoke$arity$1 ? fexpr__7591.cljs$core$IFn$_invoke$arity$1("msg") : fexpr__7591.call(null,"msg"));
})();
cljs.core.reset_BANG_(simplefrontend.products.my_response_atom,response);

cljs.core.reset_BANG_(simplefrontend.products.my_error_msg_atom,error_msg);

return cljs.core.reset_BANG_(simplefrontend.products.my_success_msg_atom,null);
});
/**
 * Does the GET for products
 */
simplefrontend.products._get_products = (function simplefrontend$products$_get_products(token,pg_id){
var url = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(simplefrontend.config.get_base_url()),"/products/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(pg_id)].join('');
var response = ajax.core.GET.cljs$core$IFn$_invoke$arity$variadic(url,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$format,cljs.core.cst$kw$json,cljs.core.cst$kw$response_DASH_format,cljs.core.cst$kw$json,cljs.core.cst$kw$headers,new cljs.core.PersistentArrayMap(null, 3, ["Accept","application/json","Content-Type","application/json","Authorization",token], null),cljs.core.cst$kw$handler,simplefrontend.products._handler,cljs.core.cst$kw$error_DASH_handler,simplefrontend.products._error_handler], null)], 0));
console.log(["Response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

return response;
});
simplefrontend.products._products_table = (function simplefrontend$products$_products_table(data){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.table,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$striped,true,cljs.core.cst$kw$bordered,true,cljs.core.cst$kw$condensed,true,cljs.core.cst$kw$hover,true], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$thead,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$tr,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$th,"Id"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$th,"Name"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$th,"Price"], null)], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$tbody,cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (item){
var vec__7592 = item;
var p_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7592,(0),null);
var pg_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7592,(1),null);
var name = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7592,(2),null);
var price = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7592,(3),null);
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$tr,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$key,p_id], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$td,p_id], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$td,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$href,["#/product/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(pg_id),"/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(p_id)].join('')], null),name], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$td,price], null)], null);
}),data)], null)], null);
});
/**
 * The actual page function called by simplefrontend.core.
 */
simplefrontend.products.products_page = (function simplefrontend$products$products_page(token,pg_id){
console.log(["ENTER products-page, pg-id: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(pg_id)].join(''));

var response = simplefrontend.products._get_products(token,pg_id);
var category = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(pg_id,"1"))?"Books":"Movies");
return ((function (response,category){
return (function (){
return new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$h1,["Products: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(category)].join('')], null),((!((cljs.core.deref(simplefrontend.products.my_products_atom) == null)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,simplefrontend.products._products_table(cljs.core.deref(simplefrontend.products.my_products_atom))], null):null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$href,"#/productgroups"], null),"Back to Product Groups page"], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$href,"#/"], null),"Back to Web Store Home Page"], null)], null)], null);
});
;})(response,category))
});

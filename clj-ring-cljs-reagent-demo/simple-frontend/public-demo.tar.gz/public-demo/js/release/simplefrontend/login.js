// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.login');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('reagent.core');
goog.require('ajax.core');
goog.require('secretary.core');
goog.require('simplefrontend.session');
goog.require('simplefrontend.components');
goog.require('simplefrontend.reagent_wrapper');
goog.require('simplefrontend.config');
simplefrontend.login.my_error_msg_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.login.my_success_msg_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.login.my_response_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
/**
 * Reset page atoms when coming here from home page.
 */
simplefrontend.login.reset_page = (function simplefrontend$login$reset_page(){
cljs.core.reset_BANG_(simplefrontend.login.my_response_atom,null);

cljs.core.reset_BANG_(simplefrontend.login.my_error_msg_atom,null);

return cljs.core.reset_BANG_(simplefrontend.login.my_success_msg_atom,null);
});
/**
 * The success (http status 200) handler.
 */
simplefrontend.login._handler = (function simplefrontend$login$_handler(response){
console.log(["ENTER -handler, response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

var token = (response.cljs$core$IFn$_invoke$arity$1 ? response.cljs$core$IFn$_invoke$arity$1("json-web-token") : response.call(null,"json-web-token"));
var dummy = console.log(["token: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(token)].join(''));
cljs.core.reset_BANG_(simplefrontend.login.my_response_atom,response);

cljs.core.reset_BANG_(simplefrontend.login.my_success_msg_atom,["Cool, login successful! ","You can now proceed to browse product groups! "].join(''));

cljs.core.reset_BANG_(simplefrontend.login.my_error_msg_atom,null);

simplefrontend.session.set_token(token);

return document.location = "/#/productgroups";
});
/**
 * The error (http status not 200) handler.
 */
simplefrontend.login._error_handler = (function simplefrontend$login$_error_handler(response){
console.log(["ENTER -error-handler, response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

var error_msg = (function (){var fexpr__7587 = cljs.core.cst$kw$response.cljs$core$IFn$_invoke$arity$1(response);
return (fexpr__7587.cljs$core$IFn$_invoke$arity$1 ? fexpr__7587.cljs$core$IFn$_invoke$arity$1("msg") : fexpr__7587.call(null,"msg"));
})();
cljs.core.reset_BANG_(simplefrontend.login.my_response_atom,response);

cljs.core.reset_BANG_(simplefrontend.login.my_error_msg_atom,error_msg);

return cljs.core.reset_BANG_(simplefrontend.login.my_success_msg_atom,null);
});
/**
 * Send form data to server using POST.
 */
simplefrontend.login._submit_form = (function simplefrontend$login$_submit_form(email,password){
console.log(["ENTER submit-form, email: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(email)].join(''));

var url = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(simplefrontend.config.get_base_url()),"/login"].join('');
var data = new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$email,email,cljs.core.cst$kw$password,password], null);
var response = ajax.core.POST.cljs$core$IFn$_invoke$arity$variadic(url,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$format,cljs.core.cst$kw$json,cljs.core.cst$kw$params,data,cljs.core.cst$kw$response_DASH_format,cljs.core.cst$kw$json,cljs.core.cst$kw$headers,new cljs.core.PersistentArrayMap(null, 2, ["Accept","application/json","Content-Type","application/json"], null),cljs.core.cst$kw$handler,simplefrontend.login._handler,cljs.core.cst$kw$error_DASH_handler,simplefrontend.login._error_handler], null)], 0));
return console.log(["Response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));
});
/**
 * The actual page function called by simplefrontend.core.
 */
simplefrontend.login.login_page = (function simplefrontend$login$login_page(){
console.log(["ENTER login-page"].join(''));

var email_address_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var password_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
return ((function (email_address_atom,password_atom){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$h1,"Login"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$form,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.grid,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.components.input("Email address: ","email-address","text",email_address_atom)], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.components.input("Password: ","password","text",password_atom)], null)], null)], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$input,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$type,"button",cljs.core.cst$kw$value,"Submit",cljs.core.cst$kw$on_DASH_click,((function (email_address_atom,password_atom){
return (function (){
return simplefrontend.login._submit_form(cljs.core.deref(email_address_atom),cljs.core.deref(password_atom));
});})(email_address_atom,password_atom))
], null)], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.grid,((!((cljs.core.deref(simplefrontend.login.my_error_msg_atom) == null)))?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.components.msg_field("Error: ","error","text","red",cljs.core.deref(simplefrontend.login.my_error_msg_atom))], null):null),((!((cljs.core.deref(simplefrontend.login.my_success_msg_atom) == null)))?new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.components.msg_field("Success: ","success","text","greenyellow",cljs.core.deref(simplefrontend.login.my_success_msg_atom))], null):null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$href,"#/"], null),"Back to Web Store Home Page"], null)], null)], null);
});
;})(email_address_atom,password_atom))
});

// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.prod');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('simplefrontend.core');
cljs.core._STAR_print_fn_STAR_ = (function() { 
var G__7664__delegate = function (_){
return null;
};
var G__7664 = function (var_args){
var _ = null;
if (arguments.length > 0) {
var G__7665__i = 0, G__7665__a = new Array(arguments.length -  0);
while (G__7665__i < G__7665__a.length) {G__7665__a[G__7665__i] = arguments[G__7665__i + 0]; ++G__7665__i;}
  _ = new cljs.core.IndexedSeq(G__7665__a,0,null);
} 
return G__7664__delegate.call(this,_);};
G__7664.cljs$lang$maxFixedArity = 0;
G__7664.cljs$lang$applyTo = (function (arglist__7666){
var _ = cljs.core.seq(arglist__7666);
return G__7664__delegate(_);
});
G__7664.cljs$core$IFn$_invoke$arity$variadic = G__7664__delegate;
return G__7664;
})()
;
simplefrontend.core.init_BANG_();

// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.productgroups');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('reagent.core');
goog.require('ajax.core');
goog.require('simplefrontend.reagent_wrapper');
goog.require('simplefrontend.config');
simplefrontend.productgroups.my_error_msg_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.productgroups.my_success_msg_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.productgroups.my_response_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.productgroups.my_product_groups_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.productgroups.my_dev_product_groups_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentArrayMap(null, 2, ["1","Books","2","Movies"], null));
/**
 * Reset page atoms when coming here from home page.
 */
simplefrontend.productgroups.reset_page = (function simplefrontend$productgroups$reset_page(){
cljs.core.reset_BANG_(simplefrontend.productgroups.my_response_atom,null);

cljs.core.reset_BANG_(simplefrontend.productgroups.my_error_msg_atom,null);

return cljs.core.reset_BANG_(simplefrontend.productgroups.my_success_msg_atom,null);
});
/**
 * The success (http status 200) handler.
 */
simplefrontend.productgroups._handler = (function simplefrontend$productgroups$_handler(response){
console.log(["ENTER -handler, response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

cljs.core.reset_BANG_(simplefrontend.productgroups.my_response_atom,response);

cljs.core.reset_BANG_(simplefrontend.productgroups.my_product_groups_atom,(function (){var fexpr__7597 = cljs.core.deref(simplefrontend.productgroups.my_response_atom);
return (fexpr__7597.cljs$core$IFn$_invoke$arity$1 ? fexpr__7597.cljs$core$IFn$_invoke$arity$1("product-groups") : fexpr__7597.call(null,"product-groups"));
})());

cljs.core.reset_BANG_(simplefrontend.productgroups.my_success_msg_atom,"TODO");

return cljs.core.reset_BANG_(simplefrontend.productgroups.my_error_msg_atom,null);
});
/**
 * The error (http status not 200) handler.
 */
simplefrontend.productgroups._error_handler = (function simplefrontend$productgroups$_error_handler(response){
console.log(["ENTER -error-handler, response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

var error_msg = (function (){var fexpr__7598 = cljs.core.cst$kw$response.cljs$core$IFn$_invoke$arity$1(response);
return (fexpr__7598.cljs$core$IFn$_invoke$arity$1 ? fexpr__7598.cljs$core$IFn$_invoke$arity$1("msg") : fexpr__7598.call(null,"msg"));
})();
cljs.core.reset_BANG_(simplefrontend.productgroups.my_response_atom,response);

cljs.core.reset_BANG_(simplefrontend.productgroups.my_error_msg_atom,error_msg);

return cljs.core.reset_BANG_(simplefrontend.productgroups.my_success_msg_atom,null);
});
/**
 * Does the GET for productgroups
 */
simplefrontend.productgroups._get_productgroups = (function simplefrontend$productgroups$_get_productgroups(token){
var url = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(simplefrontend.config.get_base_url()),"/product-groups"].join('');
var response = ajax.core.GET.cljs$core$IFn$_invoke$arity$variadic(url,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$format,cljs.core.cst$kw$json,cljs.core.cst$kw$response_DASH_format,cljs.core.cst$kw$json,cljs.core.cst$kw$headers,new cljs.core.PersistentArrayMap(null, 3, ["Accept","application/json","Content-Type","application/json","Authorization",token], null),cljs.core.cst$kw$handler,simplefrontend.productgroups._handler,cljs.core.cst$kw$error_DASH_handler,simplefrontend.productgroups._error_handler], null)], 0));
console.log(["Response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

return response;
});
simplefrontend.productgroups._product_groups_table = (function simplefrontend$productgroups$_product_groups_table(data){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.table,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$striped,true,cljs.core.cst$kw$bordered,true,cljs.core.cst$kw$condensed,true,cljs.core.cst$kw$hover,true], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$thead,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$tr,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$th,"Id"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$th,"Name"], null)], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$tbody,cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (item){
var vec__7599 = item;
var my_key = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7599,(0),null);
var my_value = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7599,(1),null);
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$tr,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$key,my_key], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$td,my_key], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$td,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$href,["#/products/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(my_key)].join('')], null),my_value], null)], null)], null);
}),data)], null)], null);
});
/**
 * The actual page function called by simplefrontend.core.
 */
simplefrontend.productgroups.productgroups_page = (function simplefrontend$productgroups$productgroups_page(token){
console.log(["ENTER productgroups-page"].join(''));

var response = simplefrontend.productgroups._get_productgroups(token);
return ((function (response){
return (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$h1,"Product Groups"], null),((!((cljs.core.deref(simplefrontend.productgroups.my_product_groups_atom) == null)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,simplefrontend.productgroups._product_groups_table(cljs.core.deref(simplefrontend.productgroups.my_product_groups_atom))], null):null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$href,"#/"], null),"Back to Web Store Home Page"], null)], null)], null);
});
;})(response))
});

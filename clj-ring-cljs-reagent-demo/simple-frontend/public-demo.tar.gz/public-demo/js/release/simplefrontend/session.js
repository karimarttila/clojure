// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.session');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('goog.crypt.base64');
goog.require('reagent.core');
goog.require('ajax.core');
simplefrontend.session.app_state = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
simplefrontend.session.page_params = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
simplefrontend.session.token_key = "sf-token";
/**
 * Does the base64 encoding for the string
 */
simplefrontend.session._base64_encode = (function simplefrontend$session$_base64_encode(str){
return goog.crypt.base64.encodeString(str,false);
});
/**
 * Encodes the token to be used for pages
 */
simplefrontend.session._encode_token = (function simplefrontend$session$_encode_token(token){
return ["Basic ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(simplefrontend.session._base64_encode([cljs.core.str.cljs$core$IFn$_invoke$arity$1(token)].join('')))].join('');
});
/**
 * Gets the encoded token for pages
 */
simplefrontend.session.get_encoded_token = (function simplefrontend$session$get_encoded_token(){
var token_from_app_state = (function (){var G__7282 = cljs.core.cst$kw$token;
var fexpr__7281 = cljs.core.deref(simplefrontend.session.app_state);
return (fexpr__7281.cljs$core$IFn$_invoke$arity$1 ? fexpr__7281.cljs$core$IFn$_invoke$arity$1(G__7282) : fexpr__7281.call(null,G__7282));
})();
var token = (cljs.core.truth_(token_from_app_state)?token_from_app_state:window.localStorage.getItem(simplefrontend.session.token_key));
return simplefrontend.session._encode_token(token);
});
/**
 * Sets the token for the application
 */
simplefrontend.session.set_token = (function simplefrontend$session$set_token(token){
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(simplefrontend.session.app_state,cljs.core.assoc,cljs.core.cst$kw$token,token);

return window.localStorage.setItem(simplefrontend.session.token_key,token);
});
simplefrontend.session.set_page_params_BANG_ = (function simplefrontend$session$set_page_params_BANG_(page,params){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(simplefrontend.session.page_params,cljs.core.assoc,page,params);
});
simplefrontend.session.get_page_params = (function simplefrontend$session$get_page_params(page){
var fexpr__7283 = cljs.core.deref(simplefrontend.session.page_params);
return (fexpr__7283.cljs$core$IFn$_invoke$arity$1 ? fexpr__7283.cljs$core$IFn$_invoke$arity$1(page) : fexpr__7283.call(null,page));
});
simplefrontend.session.set_current_page_BANG_ = (function simplefrontend$session$set_current_page_BANG_(page){
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(simplefrontend.session.app_state,cljs.core.assoc,cljs.core.cst$kw$page,page);
});
simplefrontend.session.get_current_page = (function simplefrontend$session$get_current_page(){
var G__7285 = cljs.core.cst$kw$page;
var fexpr__7284 = cljs.core.deref(simplefrontend.session.app_state);
return (fexpr__7284.cljs$core$IFn$_invoke$arity$1 ? fexpr__7284.cljs$core$IFn$_invoke$arity$1(G__7285) : fexpr__7284.call(null,G__7285));
});

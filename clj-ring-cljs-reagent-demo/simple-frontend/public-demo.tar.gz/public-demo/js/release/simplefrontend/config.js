// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.config');
goog.require('cljs.core');
goog.require('cljs.core.constants');
simplefrontend.config.backend_host_config = new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$host,"localhost",cljs.core.cst$kw$port,(3045)], null);
simplefrontend.config.get_base_url = (function simplefrontend$config$get_base_url(){
var host = cljs.core.cst$kw$host.cljs$core$IFn$_invoke$arity$1(simplefrontend.config.backend_host_config);
var port = cljs.core.cst$kw$port.cljs$core$IFn$_invoke$arity$1(simplefrontend.config.backend_host_config);
var url = ["http://",cljs.core.str.cljs$core$IFn$_invoke$arity$1(host),":",cljs.core.str.cljs$core$IFn$_invoke$arity$1(port)].join('');
return url;
});

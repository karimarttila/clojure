// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('goog.History');
goog.require('secretary.core');
goog.require('goog.events');
goog.require('goog.history.EventType');
goog.require('reagent.core');
goog.require('simplefrontend.session');
goog.require('simplefrontend.layout');
goog.require('simplefrontend.home');
goog.require('simplefrontend.login');
goog.require('simplefrontend.signin');
goog.require('simplefrontend.productgroups');
goog.require('simplefrontend.products');
goog.require('simplefrontend.product');
simplefrontend.core.hook_browser_navigation_BANG_ = (function simplefrontend$core$hook_browser_navigation_BANG_(){
var G__7613 = (new goog.History());
var G__7614_7617 = G__7613;
var G__7615_7618 = goog.history.EventType.NAVIGATE;
var G__7616_7619 = ((function (G__7614_7617,G__7615_7618,G__7613){
return (function (event){
return secretary.core.dispatch_BANG_(event.token);
});})(G__7614_7617,G__7615_7618,G__7613))
;
goog.events.listen(G__7614_7617,G__7615_7618,G__7616_7619);

G__7613.setEnabled(true);

return G__7613;
});
simplefrontend.core.app_routes = (function simplefrontend$core$app_routes(){
secretary.core.set_config_BANG_(cljs.core.cst$kw$prefix,"#");

var action__7305__auto___7650 = (function (params__7306__auto__){
if(cljs.core.map_QMARK_(params__7306__auto__)){
var map__7620 = params__7306__auto__;
var map__7620__$1 = ((((!((map__7620 == null)))?(((((map__7620.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__7620.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__7620):map__7620);
return simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$home);
} else {
if(cljs.core.vector_QMARK_(params__7306__auto__)){
var vec__7622 = params__7306__auto__;
return simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$home);
} else {
return null;
}
}
});
secretary.core.add_route_BANG_("/",action__7305__auto___7650);


var action__7305__auto___7651 = (function (params__7306__auto__){
if(cljs.core.map_QMARK_(params__7306__auto__)){
var map__7625 = params__7306__auto__;
var map__7625__$1 = ((((!((map__7625 == null)))?(((((map__7625.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__7625.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__7625):map__7625);
return simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$signin);
} else {
if(cljs.core.vector_QMARK_(params__7306__auto__)){
var vec__7627 = params__7306__auto__;
return simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$signin);
} else {
return null;
}
}
});
secretary.core.add_route_BANG_("/signin",action__7305__auto___7651);


var action__7305__auto___7652 = (function (params__7306__auto__){
if(cljs.core.map_QMARK_(params__7306__auto__)){
var map__7630 = params__7306__auto__;
var map__7630__$1 = ((((!((map__7630 == null)))?(((((map__7630.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__7630.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__7630):map__7630);
return simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$login);
} else {
if(cljs.core.vector_QMARK_(params__7306__auto__)){
var vec__7632 = params__7306__auto__;
return simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$login);
} else {
return null;
}
}
});
secretary.core.add_route_BANG_("/login",action__7305__auto___7652);


var action__7305__auto___7653 = (function (params__7306__auto__){
if(cljs.core.map_QMARK_(params__7306__auto__)){
var map__7635 = params__7306__auto__;
var map__7635__$1 = ((((!((map__7635 == null)))?(((((map__7635.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__7635.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__7635):map__7635);
return simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$productgroups);
} else {
if(cljs.core.vector_QMARK_(params__7306__auto__)){
var vec__7637 = params__7306__auto__;
return simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$productgroups);
} else {
return null;
}
}
});
secretary.core.add_route_BANG_("/productgroups",action__7305__auto___7653);


var action__7305__auto___7654 = (function (params__7306__auto__){
if(cljs.core.map_QMARK_(params__7306__auto__)){
var map__7640 = params__7306__auto__;
var map__7640__$1 = ((((!((map__7640 == null)))?(((((map__7640.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__7640.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__7640):map__7640);
var pg_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__7640__$1,cljs.core.cst$kw$pg_DASH_id);
simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$products);

return simplefrontend.session.set_page_params_BANG_(cljs.core.cst$kw$products,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$pg_DASH_id,pg_id], null));
} else {
if(cljs.core.vector_QMARK_(params__7306__auto__)){
var vec__7642 = params__7306__auto__;
var pg_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7642,(0),null);
simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$products);

return simplefrontend.session.set_page_params_BANG_(cljs.core.cst$kw$products,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$pg_DASH_id,pg_id], null));
} else {
return null;
}
}
});
secretary.core.add_route_BANG_("/products/:pg-id",action__7305__auto___7654);


var action__7305__auto___7655 = (function (params__7306__auto__){
if(cljs.core.map_QMARK_(params__7306__auto__)){
var map__7645 = params__7306__auto__;
var map__7645__$1 = ((((!((map__7645 == null)))?(((((map__7645.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__7645.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__7645):map__7645);
var pg_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__7645__$1,cljs.core.cst$kw$pg_DASH_id);
var p_id = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__7645__$1,cljs.core.cst$kw$p_DASH_id);
simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$product);

return simplefrontend.session.set_page_params_BANG_(cljs.core.cst$kw$product,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pg_DASH_id,pg_id,cljs.core.cst$kw$p_DASH_id,p_id], null));
} else {
if(cljs.core.vector_QMARK_(params__7306__auto__)){
var vec__7647 = params__7306__auto__;
var pg_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7647,(0),null);
var p_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7647,(1),null);
simplefrontend.session.set_current_page_BANG_(cljs.core.cst$kw$product);

return simplefrontend.session.set_page_params_BANG_(cljs.core.cst$kw$product,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pg_DASH_id,pg_id,cljs.core.cst$kw$p_DASH_id,p_id], null));
} else {
return null;
}
}
});
secretary.core.add_route_BANG_("/product/:pg-id/:p-id",action__7305__auto___7655);


return simplefrontend.core.hook_browser_navigation_BANG_();
});
simplefrontend.core.home = (function simplefrontend$core$home(){
return simplefrontend.home.home_page();
});
simplefrontend.core.signin = (function simplefrontend$core$signin(){
simplefrontend.signin.reset_page();

return simplefrontend.signin.signin_page();
});
simplefrontend.core.login = (function simplefrontend$core$login(){
simplefrontend.login.reset_page();

return simplefrontend.login.login_page();
});
simplefrontend.core.productgroups = (function simplefrontend$core$productgroups(){
simplefrontend.productgroups.reset_page();

return simplefrontend.productgroups.productgroups_page(simplefrontend.session.get_encoded_token());
});
simplefrontend.core.products = (function simplefrontend$core$products(){
simplefrontend.products.reset_page();

return simplefrontend.products.products_page(simplefrontend.session.get_encoded_token(),(function (){var G__7657 = cljs.core.cst$kw$pg_DASH_id;
var fexpr__7656 = simplefrontend.session.get_page_params(cljs.core.cst$kw$products);
return (fexpr__7656.cljs$core$IFn$_invoke$arity$1 ? fexpr__7656.cljs$core$IFn$_invoke$arity$1(G__7657) : fexpr__7656.call(null,G__7657));
})());
});
simplefrontend.core.product = (function simplefrontend$core$product(){
simplefrontend.product.reset_page();

return simplefrontend.product.product_page(simplefrontend.session.get_encoded_token(),(function (){var G__7659 = cljs.core.cst$kw$pg_DASH_id;
var fexpr__7658 = simplefrontend.session.get_page_params(cljs.core.cst$kw$product);
return (fexpr__7658.cljs$core$IFn$_invoke$arity$1 ? fexpr__7658.cljs$core$IFn$_invoke$arity$1(G__7659) : fexpr__7658.call(null,G__7659));
})(),(function (){var G__7661 = cljs.core.cst$kw$p_DASH_id;
var fexpr__7660 = simplefrontend.session.get_page_params(cljs.core.cst$kw$product);
return (fexpr__7660.cljs$core$IFn$_invoke$arity$1 ? fexpr__7660.cljs$core$IFn$_invoke$arity$1(G__7661) : fexpr__7660.call(null,G__7661));
})());
});
if(typeof simplefrontend.core.current_page !== 'undefined'){
} else {
simplefrontend.core.current_page = (function (){var method_table__4382__auto__ = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__4383__auto__ = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var method_cache__4384__auto__ = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__4385__auto__ = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__4386__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$3(cljs.core.PersistentArrayMap.EMPTY,cljs.core.cst$kw$hierarchy,cljs.core.get_global_hierarchy());
return (new cljs.core.MultiFn(cljs.core.symbol.cljs$core$IFn$_invoke$arity$2("simplefrontend.core","current-page"),((function (method_table__4382__auto__,prefer_table__4383__auto__,method_cache__4384__auto__,cached_hierarchy__4385__auto__,hierarchy__4386__auto__){
return (function (){
return simplefrontend.session.get_current_page();
});})(method_table__4382__auto__,prefer_table__4383__auto__,method_cache__4384__auto__,cached_hierarchy__4385__auto__,hierarchy__4386__auto__))
,cljs.core.cst$kw$default,hierarchy__4386__auto__,method_table__4382__auto__,prefer_table__4383__auto__,method_cache__4384__auto__,cached_hierarchy__4385__auto__));
})();
}
simplefrontend.core.current_page.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$home,(function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.core.home], null);
}));
simplefrontend.core.current_page.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$signin,(function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.core.signin], null);
}));
simplefrontend.core.current_page.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$login,(function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.core.login], null);
}));
simplefrontend.core.current_page.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$productgroups,(function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.core.productgroups], null);
}));
simplefrontend.core.current_page.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$products,(function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.core.products], null);
}));
simplefrontend.core.current_page.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$product,(function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.core.product], null);
}));
simplefrontend.core.current_page.cljs$core$IMultiFn$_add_method$arity$3(null,cljs.core.cst$kw$default,(function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div], null);
}));
simplefrontend.core.mount_root = (function simplefrontend$core$mount_root(){
simplefrontend.core.app_routes();

return reagent.core.render.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.layout.main_layout,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.core.current_page], null)], null),document.getElementById("app"));
});
simplefrontend.core.init_BANG_ = (function simplefrontend$core$init_BANG_(){
return simplefrontend.core.mount_root();
});

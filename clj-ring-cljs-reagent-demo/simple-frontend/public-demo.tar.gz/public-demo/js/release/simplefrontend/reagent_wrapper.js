// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.reagent_wrapper');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('reagent.core');
simplefrontend.reagent_wrapper.grid = reagent.core.adapt_react_class((ReactBootstrap["Grid"]));
simplefrontend.reagent_wrapper.col = reagent.core.adapt_react_class((ReactBootstrap["Col"]));
simplefrontend.reagent_wrapper.row = reagent.core.adapt_react_class((ReactBootstrap["Row"]));
simplefrontend.reagent_wrapper.table = reagent.core.adapt_react_class((ReactBootstrap["Table"]));

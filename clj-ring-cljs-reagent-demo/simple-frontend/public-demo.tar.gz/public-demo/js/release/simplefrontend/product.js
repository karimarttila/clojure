// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.product');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('reagent.core');
goog.require('ajax.core');
goog.require('simplefrontend.reagent_wrapper');
goog.require('simplefrontend.config');
simplefrontend.product.my_error_msg_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.product.my_success_msg_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.product.my_response_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.product.my_product_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
simplefrontend.product.my_dev_product_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentVector(null, 8, 5, cljs.core.PersistentVector.EMPTY_NODE, ["2011","1","The Decameron","29.03","Giovanni Boccaccio","1351","Italy","Italian"], null));
/**
 * Reset page atoms when coming here from home page.
 */
simplefrontend.product.reset_page = (function simplefrontend$product$reset_page(){
cljs.core.reset_BANG_(simplefrontend.product.my_response_atom,null);

cljs.core.reset_BANG_(simplefrontend.product.my_error_msg_atom,null);

return cljs.core.reset_BANG_(simplefrontend.product.my_success_msg_atom,null);
});
/**
 * The success (http status 200) handler.
 */
simplefrontend.product._handler = (function simplefrontend$product$_handler(response){
console.log(["ENTER -handler, response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

cljs.core.reset_BANG_(simplefrontend.product.my_response_atom,response);

cljs.core.reset_BANG_(simplefrontend.product.my_product_atom,(function (){var fexpr__7606 = cljs.core.deref(simplefrontend.product.my_response_atom);
return (fexpr__7606.cljs$core$IFn$_invoke$arity$1 ? fexpr__7606.cljs$core$IFn$_invoke$arity$1("product") : fexpr__7606.call(null,"product"));
})());

cljs.core.reset_BANG_(simplefrontend.product.my_success_msg_atom,"TODO");

return cljs.core.reset_BANG_(simplefrontend.product.my_error_msg_atom,null);
});
/**
 * The error (http status not 200) handler.
 */
simplefrontend.product._error_handler = (function simplefrontend$product$_error_handler(response){
console.log(["ENTER -error-handler, response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

var error_msg = (function (){var fexpr__7607 = cljs.core.cst$kw$response.cljs$core$IFn$_invoke$arity$1(response);
return (fexpr__7607.cljs$core$IFn$_invoke$arity$1 ? fexpr__7607.cljs$core$IFn$_invoke$arity$1("msg") : fexpr__7607.call(null,"msg"));
})();
cljs.core.reset_BANG_(simplefrontend.product.my_response_atom,response);

cljs.core.reset_BANG_(simplefrontend.product.my_error_msg_atom,error_msg);

return cljs.core.reset_BANG_(simplefrontend.product.my_success_msg_atom,null);
});
/**
 * Does the GET for product
 */
simplefrontend.product._get_product = (function simplefrontend$product$_get_product(token,pg_id,p_id){
var url = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(simplefrontend.config.get_base_url()),"/product/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(pg_id),"/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(p_id)].join('');
var response = ajax.core.GET.cljs$core$IFn$_invoke$arity$variadic(url,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$format,cljs.core.cst$kw$json,cljs.core.cst$kw$response_DASH_format,cljs.core.cst$kw$json,cljs.core.cst$kw$headers,new cljs.core.PersistentArrayMap(null, 3, ["Accept","application/json","Content-Type","application/json","Authorization",token], null),cljs.core.cst$kw$handler,simplefrontend.product._handler,cljs.core.cst$kw$error_DASH_handler,simplefrontend.product._error_handler], null)], 0));
console.log(["Response: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(response)].join(''));

return response;
});
simplefrontend.product._product_table = (function simplefrontend$product$_product_table(data,titles){
var table_values = cljs.core.map.cljs$core$IFn$_invoke$arity$3(cljs.core.list,titles,data);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.table,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$striped,true,cljs.core.cst$kw$bordered,true,cljs.core.cst$kw$condensed,true,cljs.core.cst$kw$hover,true], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$tbody,cljs.core.map.cljs$core$IFn$_invoke$arity$2(((function (table_values){
return (function (item){
var vec__7608 = item;
var field = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7608,(0),null);
var value = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__7608,(1),null);
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$tr,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$key,field], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$td,field], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$td,value], null)], null);
});})(table_values))
,table_values)], null)], null);
});
/**
 * The actual page function called by simplefrontend.core.
 */
simplefrontend.product.product_page = (function simplefrontend$product$product_page(token,pg_id,p_id){
console.log(["ENTER product-page, pg-id: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(pg_id),", p-id: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(p_id)].join(''));

var response = simplefrontend.product._get_product(token,pg_id,p_id);
var titles = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(pg_id,"1"))?new cljs.core.PersistentVector(null, 8, 5, cljs.core.PersistentVector.EMPTY_NODE, ["Id","Pg-Id","Name","Price","Author","Year","Country","Language"], null):new cljs.core.PersistentVector(null, 8, 5, cljs.core.PersistentVector.EMPTY_NODE, ["Id","Pg-Id","Name","Price","Director","Year","Country","Category"], null));
return ((function (response,titles){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$h1,"Product"], null),((!((cljs.core.deref(simplefrontend.product.my_product_atom) == null)))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,simplefrontend.product._product_table(cljs.core.deref(simplefrontend.product.my_product_atom),titles)], null):null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$href,["#/products/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(pg_id)].join('')], null),"Back to Products page"], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$href,"#/productgroups"], null),"Back to Product Groups page"], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$a,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$href,"#/"], null),"Back to Web Store Home Page"], null)], null)], null);
});
;})(response,titles))
});

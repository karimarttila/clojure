// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('simplefrontend.components');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('reagent.core');
goog.require('simplefrontend.reagent_wrapper');
goog.require('ajax.core');
/**
 * Input field component for e.g. First name, Last name, Email address and Password.
 */
simplefrontend.components.input = (function simplefrontend$components$input(label,name,type,my_atom){
return (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.row,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$class,"show-grid"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.col,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$xs,(3),cljs.core.cst$kw$md,(2)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$label,label], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.col,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$xs,(3),cljs.core.cst$kw$md,(2)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$input,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,name,cljs.core.cst$kw$name,name,cljs.core.cst$kw$type,type,cljs.core.cst$kw$value,cljs.core.deref(my_atom),cljs.core.cst$kw$on_DASH_change,(function (p1__7288_SHARP_){
return cljs.core.reset_BANG_(my_atom,p1__7288_SHARP_.target.value);
})], null)], null)], null)], null)], null);
});
});
/**
 * Message field component for success/error feedback.
 */
simplefrontend.components.msg_field = (function simplefrontend$components$msg_field(label,name,type,color,err_msg){
return (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.row,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$class,"show-grid"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.col,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$xs,(3),cljs.core.cst$kw$md,(2)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$label,label], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [simplefrontend.reagent_wrapper.col,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$xs,(3),cljs.core.cst$kw$md,(2)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$textarea,new cljs.core.PersistentArrayMap(null, 8, [cljs.core.cst$kw$id,name,cljs.core.cst$kw$name,name,cljs.core.cst$kw$type,type,cljs.core.cst$kw$rows,(2),cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$background_DASH_color,color], null),cljs.core.cst$kw$cols,(50),cljs.core.cst$kw$value,err_msg,cljs.core.cst$kw$read_DASH_only,true], null)], null)], null)], null)], null);
});
});

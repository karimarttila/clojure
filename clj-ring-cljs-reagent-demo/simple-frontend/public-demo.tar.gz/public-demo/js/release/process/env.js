// Compiled by ClojureScript 1.10.238 {:static-fns true, :optimize-constants true}
goog.provide('process.env');
goog.require('cljs.core');
goog.require('cljs.core.constants');

/** @define {string} */
goog.define("process.env.NODE_ENV","development");
